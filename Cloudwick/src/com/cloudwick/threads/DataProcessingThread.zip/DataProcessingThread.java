package com.cloudwick.threads;

import java.io.File;

public class DataProcessingThread extends Thread {
	File fileToProcess;
	File logFile;
	File outputFile;

	public DataProcessingThread(File fileToProcess, File logFile,
			File outputFile) {
		this.fileToProcess = fileToProcess;
		this.logFile = logFile;
		this.outputFile = outputFile;
	}

	public void run() {
		if (fileToProcess.isDirectory()) {
			Assignment.processData(fileToProcess, logFile, outputFile);
		} else if (fileToProcess.isFile()) {
						System.out.println();

		}
	}

}
